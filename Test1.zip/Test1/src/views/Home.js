/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View} from 'react-native';
import Swipeable from '../components/Swipeable';
var Sound = require('react-native-sound');


const DATA = [
  { id: 1, img : require('../assets/coreimg/hwyappphrase1img1.png'),sound1: '../assets/audio/hwyappphrase1audio1.m4a', phrase1: 'See you soon', phrase2: 'Catch you later', description: 'A  Goodbye. \nB  OK, see you soon!' },
  { id: 2, img : require('../assets/coreimg/hwyappphrase2img1.png'),sound1: '../assets/audio/hwyappphrase2audio1.m4a', phrase1: 'Sleep well', phrase2: 'Sweet dreams', description: 'A  I am really tired. I am going to bed. \nB  Yeah, me too. Sleep well '},
  { id: 3, img : require('../assets/coreimg/hwyappphrase3img1.png'),sound1: '../assets/audio/hwyappphrase3audio1.m4a', phrase1: 'lose your temper', phrase2: 'hit the roof', description: 'He loses his temper very quickly if you argue with him' },
  { id: 4, img : require('../assets/coreimg/hwyappphrase4img1.png'),sound1: '../assets/audio/hwyappphrase4audio1.m4a', phrase1: 'be addicted to sth', phrase2: 'be hooked on sth', description: 'My brother' },
  { id: 5, img : require('../assets/coreimg/hwyappphrase5img1.png'),sound1: '../assets/audio/hwyappphrase5audio1.m4a', phrase1: 'Hang on!', phrase2: 'Wait a sec!', description: 'Hang on! I will ready in two minutes.' },
  { id: 6, img : require('../assets/coreimg/hwyappphrase6img1.png'),sound1: '../assets/audio/hwyappphrase6audio1.m4a', phrase1: 'That sounds great!', phrase2: 'Good idea.', description: 'A  Shall we do this again next weeked? \nB  That sound great.' },
];

export default class Home extends Component {
  
  render() {
    return (
      <View style={styles.container}>
        <Swipeable cards={DATA} />
      </View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
  },
});