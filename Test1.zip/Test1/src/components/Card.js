import React from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet,Dimensions } from 'react-native';
import PropTypes from 'prop-types';
var Sound = require('react-native-sound');


export default class Card extends React.Component {
  static propTypes = {
    img: PropTypes.number.isRequired,
    phrase1: PropTypes.string.isRequired,
    phrase2: PropTypes.string,
    description: PropTypes.string.isRequired,
    width: PropTypes.number.isRequired,
    sound1:PropTypes.string.isRequired,
  };
  width = Dimensions.get('window').width;
  static Margin = 0;
  _PlaySound(urlsound)
  {
    let hello = new Sound('../assets/audio/file.mp3', Sound.MAIN_BUNDLE, (error) => {
      if (error) {
        console.log(error)
      }
    })
    
    hello.play((success) => {
      if (!success) {
        console.log('Sound did not play')
      }
    })
  }
  render() {
    const { phrase1, phrase2, description, img, width,sound1 } = this.props;
    return (
      <View style={[ { flex:1 }]}>
        <Image
          source={img}
          style={{width: width , height:width,resizeMode:'stretch'}}
        />
        <View style={styles.content}>
          <View style={styles.textContainer}>
            <Text style={styles.title}>{description}</Text>
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.button} onPress={() => {this._PlaySound(sound1)}}>
              <Text>{phrase1}</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.buttonContainer}>
            <TouchableOpacity style={styles.button} onPress={() => {}}>
              <Text>{phrase2}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    margin: Card.Margin,
    backgroundColor: 'white',
  },
  content: {
    minHeight: 150,
    flexDirection: 'row',
    padding: 10,
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: 'lightgray',
  },
  textContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontWeight: 'bold',
  },
  subtitle: {
    color: 'gray',
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  button: {
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: 'lightgray',
  },
});
