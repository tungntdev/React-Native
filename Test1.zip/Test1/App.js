
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,StatusBar} from 'react-native';
import ScrollableTabView from 'react-native-scrollable-tab-view';
import Home from './src/views/Home';
import Favourites from './src/views/Favourites';
import SeeAll from './src/views/SeeAll';
import Custombar from './src/components/Custombar';

export default class App extends Component {
  render() {
    return (
      <ScrollableTabView style={{marginTop: 30, }} initialPage={1}
      renderTabBar={() => <Custombar />}> 
        <Favourites tabLabel="favorite" />
        <Home tabLabel="face" />
        <SeeAll tabLabel="list" />
      </ScrollableTabView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});
